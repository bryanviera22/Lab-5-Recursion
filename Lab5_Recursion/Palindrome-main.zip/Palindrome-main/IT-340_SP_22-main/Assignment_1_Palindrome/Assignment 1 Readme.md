# Assignment 1	

This assignment is comprised of two parts

1) Get your coding system up and running and write some basic code again. In this case you can choose either the Java template or the Python template.  Complete the "Is Palindrome" method as they are written and follow the directions in the comments. Do not change the method/function names or inputs or return types.  It must return a True/False and some test cases are listed in the code (although they may not test every case). You may not use any built in  detector or String reverse functions. Don't code anything you can't analyze. 

2) Analyze the Algorithm Efficiency that you wrote. Report the Big O for your code (this can be done in the comments of the code of the submissions on canvas)



Bonus +5

Complete the "find all palindromes" code that reads a file and finds all palindromes in that file. Report the Big O of that code and explain how it may or may not differ from the previous analysis.