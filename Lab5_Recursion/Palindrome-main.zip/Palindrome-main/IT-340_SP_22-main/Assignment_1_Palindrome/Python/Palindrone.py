"""
Return True if the word is the same forwards and backwards
Do not use automatic methods for reversing the string
"""
def is_palindrome(word):
    return True

""" Open up  the file. Break into words 
print out all palindrones"""
def find_all_palindromes(file_name):
    pass



#Run a few tests

if is_palindrome('racecar'):
    print('pass')
else:
    print('fail')

if is_palindrome('mom'):
    print('pass')
else:
    print('fail')

if is_palindrome('noon'):
    print('pass')
else:
    print('fail')
