# Data Structures

Welcome to IT 340. Templates for code assignments will be given here when appropriate. If templates are not needed, all instructions will be on Canvas. You may submit the code via Canvas or you may submit your Git URL to your project if you prefer that.



You will find instructions for each assignment in a readme file in each directory.



